<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Contact extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	public function __construct(){
        parent::__construct();
		$this->load->model('contactModel');
		//redirect('#contact');
    }

	public function contact_us(){
		  $details['name'] = $this->input->post('name');
          $details['email'] = $this->input->post('email');
          $details['phone'] = $this->input->post('phone');
          $details['message'] = $this->input->post('message');
		  //var_dump($details);exit;
		  $subject = "Request for Quotation sent";
		  $subject1 = "Request for Quotation received";
		  
		  $reqId = $this->contactModel->saveContact($details);
		  $body = "Dear HSH,<br/> You have received a request for Quotation with generated request ID as: " . $reqId . " </br>The following are the details:<br/> Name: <span>" . $details['name'] . "</span><br/> Email:" . "<span>" . $details['email'] . "</span><br/> Contact: <span>" . $details['phone'] . "</span><br/><br/> Message: " . $details['message'] . "</span></br>";
		  
		  $msg = "Dear " . $details['name'] . ",<br/> We have received your mail requesting for Quotation from Home Sweet Home Decor.<br/> We will get back to you soon!!";
		  
		  if($reqId){
          $to_email = 'chirag123@mailinator.com';
		  $this->email->from($details['email']);
          $this->email->to($to_email);
		  $this->email->set_mailtype("html");
          $this->email->subject($subject1);
          $this->email->message($body);
		  
		  if($this->email->send()){
		    $this->email->from($to_email);
            $this->email->to($details['email']);
			$this->email->set_mailtype("html");
            $this->email->subject($subject);
            $this->email->message($msg);	
            $this->email->send();			
			$this->session->set_flashdata('msg','<div class="alert alert-success text-center">Your Email has been successfully sent!</div>');
			redirect('Home');
		  }
		  else{
			$this->session->set_flashdata('msg','<div class="alert alert-danger text-center">Apologies,There was an error in sending the Email! Please try again later</div>');
            redirect('Contact');
		  }

		  }
	}
	

/*
			//set to_email id to which you want to receive mails
            $to_email = 'amreen.posharkar@gmail.com';


            //configure email settings
            $config['protocol'] = 'smtp';
            $config['smtp_host'] = 'ssl://smtp.googlemail.com';
            $config['smtp_port'] = '';
            $config['smtp_user'] = 'amreen.posharkar@gmail';
            $config['smtp_pass'] = '11060147';
            $config['mailtype'] = 'html';
            $config['charset'] = 'iso-8859-1';
            $config['wordwrap'] = TRUE;
            $config['newline'] = "\r\n"; //use double quotes
            //$this->load->library('email', $config);
            $this->email->initialize($config);                        

            //send mail
            $this->email->from($email);
            $this->email->to($to_email);
            $this->email->subject($phone);
            $this->email->message($message);
            if ($this->email->send())
            {
			print 'success';
            }
            else
            {
                //error
                print 'error';
				
            }*/
			
  public function contactmails()
    {
       $data['data'] = $this->contactDetails->get_contact();

       $this->load->view('theme/header');       
       $this->load->view('contactmails',$data);
       $this->load->view('theme/footer');
    }   

	public function partyorder()
    {
       $data['data'] = $this->contactDetails->get_partyorders();

       $this->load->view('theme/header');       
       $this->load->view('partyorders',$data);
       $this->load->view('theme/footer');
    }   

	public function franchise()
    {
       $data['data'] = $this->contactDetails->get_franchise();

       $this->load->view('theme/header');       
       $this->load->view('franchise',$data);
       $this->load->view('theme/footer');
    }   

}       
